package com.example.aleko.registro_usuario;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.TextView;

public class ConfirmarDatos extends AppCompatActivity {

    TextView name, fecha, phone, mail, description;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmar_datos);

        Bundle parametros = getIntent().getExtras();
        String nombre = parametros.getString("Nombre");
        int dia = parametros.getInt("Dia");
        int mes = parametros.getInt("Mes");
        int year = parametros.getInt("Year");
        String telf = parametros.getString("Telf");
        String email = parametros.getString("Email");
        String descripcion = parametros.getString("Descripcion");

        name = (TextView) findViewById(R.id.tvNombre);
        fecha = (TextView) findViewById(R.id.tvfecha);
        phone = (TextView) findViewById(R.id.tvTelefono);
        mail = (TextView) findViewById(R.id.tvEmail);
        description = (TextView) findViewById(R.id.tvdescripcion);

        name.setText(nombre);
        String unir = String.format("dia/mes/year");
        fecha.setText(unir);
        phone.setText(telf);
        mail.setText(email);
        description.setText(descripcion);

    }

    public void editarDatos(View view){

        String name1 = name.getText().toString();
        String fecha1 = fecha.getText().toString();
        String phone1 = phone.getText().toString();
        String mail1 = mail.getText().toString();
        String description1 = description.getText().toString();

        Intent intent = new Intent(ConfirmarDatos.this, MainActivity.class);
        intent.putExtra("Name",name1);
        intent.putExtra("Date",fecha1);
        intent.putExtra("Phone",phone1);
        intent.putExtra("Mail",mail1);
        intent.putExtra("Description",description1);

        startActivity(intent);

    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event){
        if (keyCode==KeyEvent.KEYCODE_BACK){
            Intent intent = new Intent(ConfirmarDatos.this, MainActivity.class);
            startActivity(intent);
        }
        return super.onKeyDown(keyCode, event);
    }
}
