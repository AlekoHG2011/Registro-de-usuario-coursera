package com.example.aleko.registro_usuario;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText nombre,telf,email,descripcion;
    DatePicker fechanac;
    TextView tvfecha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nombre = (EditText) findViewById(R.id.editTextnombre);
        fechanac = (DatePicker) findViewById(R.id.datepicker);
        telf = (EditText) findViewById(R.id.editTextphone);
        email = (EditText) findViewById(R.id.editTextemail);
        descripcion = (EditText) findViewById(R.id.editTextdescription);
        tvfecha = (TextView) findViewById(R.id.tvfecha);

        Bundle parametros = getIntent().getExtras();
        nombre.setText(parametros.getString("Name"));
        tvfecha.setText(parametros.getString("Date"));
        telf.setText(parametros.getString("Phone"));
        email.setText(parametros.getString("Mail"));
        descripcion.setText(parametros.getString("Description"));
    }

    public void guardarDatos(View view){

        String nombre1 = nombre.getText().toString();
        int dia = fechanac.getDayOfMonth();
        int mes = fechanac.getMonth();
        int year = fechanac.getYear();
        String telf1 = telf.getText().toString();
        String email1 = email.getText().toString();
        String descripcion1 = descripcion.getText().toString();

        Intent intent = new Intent(MainActivity.this, ConfirmarDatos.class);
        intent.putExtra("Nombre",nombre1);
        intent.putExtra("Dia",dia);
        intent.putExtra("Mes",mes);
        intent.putExtra("Year",year);
        intent.putExtra("Telf",telf1);
        intent.putExtra("Email",email1);
        intent.putExtra("Descripcion",descripcion1);

        startActivity(intent);
        finish();

    }

}
